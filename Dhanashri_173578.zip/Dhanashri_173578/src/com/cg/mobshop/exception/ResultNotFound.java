package com.cg.mobshop.exception;


public class ResultNotFound extends Exception {

	public ResultNotFound() {
		// TODO Auto-generated constructor stub
	}
	public ResultNotFound(String message) {
		super(message);
	}
	
}
