package com.cg.mobshop.service;

import java.util.ArrayList;
import java.util.List;



import java.util.Map;

import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl implements MobileService {
	boolean isValid;

	@Override
	public List<Mobiles> getMobileList() {
		return dao.getMobileList();
	}

	@Override
	public Map<Integer,Mobiles> deleteMobile(String mobileIdToDelete) {
		Map<Integer,Mobiles> map=dao.getMap();
		map.remove(mobileIdToDelete);
		dao.setMap(map);
		return dao.getMap();
	}

	@Override
	public List<Mobiles> sortList(String criteria) {
		switch(criteria){
		case "1":
			List<Mobiles> mobileList1= getMobileList();
			//sort
			break;
		case "2":
						
			break;
		case "3":
			
			break;
		default:
			break;
		}
		return null;
	}
	

	@Override
	public void displayMobileList() {
		dao.displayMobileList();
		}

	
	//input validation methods
	@Override
	public boolean validateChoice(String choice) {
		isValid= choice.matches(choicepattern);
		return isValid;
	}

	@Override
	public boolean validateSortingCriteriaChoice(
			String sortingCriteriachoice) {
		isValid= sortingCriteriachoice.matches(sortingCriteriaChoicepattern);
		return isValid;
	}

	@Override
	public boolean validatemobileId(String mobileId) {
		isValid= mobileId.matches(mobileIdpattern);
		return isValid;
	}
}
