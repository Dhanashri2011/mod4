package com.cg.mobshop.service;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public interface MobileService {
	

	String choicepattern = "[1-3]{1}";
	String sortingCriteriaChoicepattern = "[1-3]{1}";
	String mobileIdpattern = "[100-200]{3}";
	
	
	MobileDAOImpl dao=new MobileDAOImpl();//creating object of MobileDAOImpl
	
	
	public List<Mobiles> getMobileList();
	public Map<Integer,Mobiles> deleteMobile(String mobileIdToDelete);
	public List<Mobiles> sortList(String criteria);
	public void displayMobileList();
	
	
	
	//validation methods
	boolean validateChoice(String choice);
	boolean validateSortingCriteriaChoice(String sortingCriteriachoice);
	boolean validatemobileId(String mobileId);
}
