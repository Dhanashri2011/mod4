package com.cg.mobshop.dto;

public class Mobiles {
	private String mobileID;
	private String name;
	private String price;
	private String quantity;
	
	public Mobiles() {
	}
	
	
	public Mobiles(String mobileID, String name, String price, String quantity) {
		super();
		this.mobileID = mobileID;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public String print() {
		return (mobileID + "\t" + name + "\t" + price + "\t" + quantity);
	}
	
	
	public String getMobileID() {
		return mobileID;
	}
	public void setMobileID(String mobileID) {
		this.mobileID = mobileID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	
}
