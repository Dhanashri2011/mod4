package com.cg.mobshop.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileServiceImpl;

class MainUI {
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		MobileServiceImpl service=new MobileServiceImpl(); //Creating object of service class
		String userChoice;
		String sortingCriteriaChoice;
		String mobileIdToDelete;
		Boolean isValid;
		
		System.out.println("welcom to Mobile Shopee");
		//displaying records from collection here
		service.displayMobileList();
		//Displaying menu
		System.out.println("Enter the operation of your choice.");
		while (true) {
			System.out.println("1.	Sort all mobile records.\n2.	Delete mobile record.\n3.	Exit.\n");
			userChoice = scan.next();
		    isValid = service.validateChoice(userChoice);
			if (isValid)
				break; // if user enter valid input then break
			else
				System.out.println("Please enter Valid Choice 1/2/3");
		}
		
		
		switch(userChoice){
		case "1":
			System.out.println("Select sorting criteria");
			while(true){
			System.out.println("1.   Mobile name.\n2.   Mobile Price\n3.   Mobile Quantity\n");
			System.out.println("Enter option : ");
			sortingCriteriaChoice=scan.next();
			isValid=service.validateSortingCriteriaChoice(sortingCriteriaChoice);
			if (isValid)
				break; // if user enter valid input then break
			else
				System.out.println("Please enter Valid Choice 1/2/3");
			}
			//sorting mobile records
			service.sortList(sortingCriteriaChoice);
			break;
		case "2":
			while(true){
				System.out.println("Enter the mobilr ID of the mobile record you want to delete : ");
				mobileIdToDelete=scan.next();
				isValid=service.validatemobileId(mobileIdToDelete);
				if (isValid)
					break; // if user enter valid input then break
				else
					System.out.println("Please enter Valid Mobile ID");
				}
			//deleting mobile records
			service.deleteMobile(mobileIdToDelete);
			service.displayMobileList();
			
			
			
			break;
		case "3":
				System.out.println("Thanks for visiting! ");
				System.exit(0);
				break;
		default:
				break;
		}//switch case closing
		
	}//main() method closing
}//class closing
