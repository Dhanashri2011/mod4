package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO{
	
	Mobiles mobile=new Mobiles();

	@Override
	public List<Mobiles> getMobileList() {
		List<Mobiles> mobileList = Util.getMobileEntries().values().stream().collect(Collectors. 
                 toCollection(ArrayList::new)); 
		
		return mobileList;
	}

	@Override
	public void displayMobileList() {
		List<Mobiles> mobileList1= getMobileList();
		
		for (Mobiles mobiles : mobileList1) {
			System.out.println(mobiles.print());
		}
		
	}

	@Override
	public Map<Integer, Mobiles> getMap() {
		Map<Integer,Mobiles> map= Util.getMobileEntries();
		return map;
	}

	@Override
	public Map<Integer, Mobiles> setMap(Map<Integer,Mobiles> map) {
		Util.setMobileEntries(map);
		return null;
	}

}
