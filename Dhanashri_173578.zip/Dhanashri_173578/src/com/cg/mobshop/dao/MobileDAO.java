package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.Util;

public interface MobileDAO {

	
	public List<Mobiles> getMobileList();
	public Map<Integer,Mobiles> getMap();
	public Map<Integer,Mobiles> setMap(Map<Integer,Mobiles> map);
	public void displayMobileList() ;
}
