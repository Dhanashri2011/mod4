package com.cg.mobshop.test;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.exception.ResultNotFound;
public class TestMobiledao {
	
	MobileDAOImpl dao = null;

	@Before
	public void setUp() throws Exception {

		dao = new MobileDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testGetMobileList() throws ResultNotFound {
		MobileDAOImpl getList=new MobileDAOImpl();
		
		getList.getMobileList();
	}
	
	
}