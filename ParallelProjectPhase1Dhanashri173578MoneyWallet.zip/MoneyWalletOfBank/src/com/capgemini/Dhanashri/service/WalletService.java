package com.capgemini.Dhanashri.service;
import java.util.Map;


public class WalletService implements WalletServiceInterface {

	@Override
	public boolean validateChoice(String n) {
		return n.matches(choicePattern);
	}

	@Override
	public boolean validateName(String n) {
		return n.matches(namePattern);
	}

	@Override
	public boolean validateAddress(String n) {
		return n.matches(addressPattern);
	}

	@Override
	public boolean validateEmail(String n) {
		return n.matches(emailPattern);
	}
	
	@Override
	public boolean validatemMbNumber(String n) {
		return n.matches(mobNumPattern);
	}

	@Override
	public boolean validatedepositChoice(String n) {
		return n.matches(depositChoicePattern);
	}

	@Override
	public boolean validateWithdrawChoice(String n) {
		return n.matches(withdrawChoicePattern);
	}

	@Override
	public boolean validateFundTransferChoice(String n) {
		return n.matches(fundTransferChoicePattern);
	}

	@Override
	public boolean validatePrintTransactionChoice(String n) {
		return n.matches(printTransactionChoicePattern);
	}

	@Override
	public boolean validateWalletBalancePattern(String n) {
		return n.matches(walletBalancePattern);
	}

	@Override
	public boolean validateDepositPattern(String n) {
		return n.matches(depositPattern);
	}

	@Override
	public boolean validateWithdrawPattern(String n) {
		return n.matches(withdrawPattern);
	}

	@Override
	public boolean validateFundPattern(String n) {
		return n.matches(fundPattern);
	}
	
	

	



}
