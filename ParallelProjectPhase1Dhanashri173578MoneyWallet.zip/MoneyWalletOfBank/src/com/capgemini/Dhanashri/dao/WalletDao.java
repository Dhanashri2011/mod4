package com.capgemini.Dhanashri.dao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import com.capgemini.Dhanashri.bean.walletCustomer;

public class WalletDao implements WalletDaoInterface {
	
	walletCustomer cust = new walletCustomer();
	protected Map<Integer, walletCustomer> info = new HashMap<Integer, walletCustomer>();

	
	@Override
	public Map<Integer, walletCustomer> storeIntoMap(walletCustomer w) {

		info.put(w.getCustId(), w);
		return info;
	}
	
	public walletCustomer find(int custId) throws ResultNotFoundException {
		cust = info.get(custId);
		if (cust != null)
			return cust;
		else
			throw new ResultNotFoundException(
					"This Customer ID does not exist!");
	}

	@Override
	public walletCustomer createAccount(String name, String address,
			String email, String mobNumber, String walletBalance) {
		cust.setName(name);
		cust.setAddress(address);
		cust.setEmail(email);
		cust.setMobNumber(mobNumber);
		cust.setWalletBalance(walletBalance);
		cust.setCustId(((int)((Math.random()*1000)+1)));
		storeIntoMap(cust);
		System.out.println("---------------------Details Saved Successfully!!!--------------------\n");
		return cust;
	}
	
}
