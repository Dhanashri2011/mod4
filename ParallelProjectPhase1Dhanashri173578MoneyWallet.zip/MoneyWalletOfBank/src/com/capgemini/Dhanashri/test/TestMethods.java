package com.capgemini.Dhanashri.test;


import org.junit.*;

import com.capgemini.Dhanashri.bean.walletCustomer;
import com.capgemini.Dhanashri.dao.ResultNotFoundException;
import com.capgemini.Dhanashri.dao.WalletDao;
public class TestMethods {

	WalletDao dao=null;
	
	@Before
	public void setUp() throws Exception{
		 dao=new WalletDao();
	}
	
	@After
	public void tearDown() throws Exception{
		 dao=null;
	}
	
	@Test
public void testFindMethod(){
		walletCustomer cust=new walletCustomer();
		walletCustomer cust1=new walletCustomer();
		cust.setAddress("hgf8");
		cust.setName("021");
		cust.setMobNumber("hjgds");
		cust.setEmail("shgf4@hg.com");
		dao.storeIntoMap(cust);
		cust1=cust;
		int id=cust.getCustId();
		try{
			cust1=dao.find(id);
			Assert.assertNotNull(cust1);
			System.out.println("Test failed");
			}
		catch(ResultNotFoundException rE){
			System.out.println(rE);
		}
		
	
		
		
		
		
		
		
	}
	
	
	
}
