package com.lab.ui;

import java.util.List;
import java.util.Set;

import com.lab.dao.AuthorDao;
import com.lab.entity.Author;
import com.lab.entity.Book;


public class AuthorMain {
	public static void main(String[] args) {
		
		 AuthorDao dao = new AuthorDao();
		
		 Author author = new Author();
		 author.setFirstName("Dhanashri");
		 author.setMiddleName("Anand");
		 author.setLastName("Sanase");
		 author.setPhoneNo("9876543210");
		 
		 	dao.beginTransaction();
			dao.addAuthor(author);
			dao.commitTransaction();
			
		 Book book = new Book();
		 book.setPrice(320);
		 book.setTitle("kjhsfg");
		 book.setAuthor(author.getFirstName());
		 book.setAuthorId(author.getAuthorId());
		 
		 Book book2 = new Book();
		 book.setPrice(650);
		 book.setTitle("kjdsjghsfg");
		 book.setAuthor(author.getFirstName());
		 book.setAuthorId(author.getAuthorId());
		 
		 author.addBooks(book);
		 author.addBooks(book2);
		 
		
		
		
		List<Book> books= dao.getAllBooks();
		for(Book book1:books){
		System.out.println("All books are :\n" + book1);
		}
		
		List<Book> books1= dao.getBooksByAuthorName("Dhanashri");
		System.out.println("All books with author anme starting with D are :\n" + books1);
		
		List<Book> books2= dao.getBooksByPrice();
		System.out.println("All books with price between 500 anf 1000 are :\n" + books2);
		
		Set<Author> author1 = dao.getAthorByBookId();
		for(Author auth:author1){
		System.out.println("Author with book id as 122 is :\n" + auth.getFirstName() + "\n");
		}
		
	}
}
