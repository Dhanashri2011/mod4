package com.lab.dao;



import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.lab.entity.Author;
import com.lab.entity.Book;


public class AuthorDao {
	private EntityManager entityManager;
	public AuthorDao() {
		entityManager = JpaUtil.getEntityManager();
	}
	
	public List<Book> getAllBooks() {
		String qry = "SELECT books FROM BOOK books";
		TypedQuery<Book> query = entityManager.createQuery(qry, Book.class);
		return query.getResultList();
	}
	
	public List<Book> getBooksByAuthorName(String author) {
		String qry = "SELECT book FROM BOOK book where book.author =:pAuthor";
		TypedQuery<Book> query = entityManager.createQuery(qry, Book.class);
		query.setParameter("pAuthor", author);
		return query.getResultList();
	}
	
	public List<Book> getBooksByPrice() {
		String qry = "SELECT book FROM BOOK book where Price BETWEEN 500 AND 1000";
		TypedQuery<Book> query = entityManager.createQuery(qry, Book.class);
		return query.getResultList();
	}
	
	public Set<Author> getAthorByBookId() {
		String qry = "SELECT book FROM BOOK book where bookId=122";
		TypedQuery<Book> query = entityManager.createQuery(qry, Book.class);
		Book book=  (Book) query.getSingleResult();
		Set<Author> auth= book.getAuthors();
		return auth;
	}


	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	public void addAuthor(Author author) {
		entityManager.persist(author);
	}
}
