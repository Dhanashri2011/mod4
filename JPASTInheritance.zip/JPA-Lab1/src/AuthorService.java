


public class AuthorService {

	
private AuthorDao dao ;

public AuthorService() {
	dao=new AuthorDao();
}

	
	public void addAuthor(Author author){
		dao.beginTransaction();
		dao.addAuthor(author);
		dao.commitTransaction();
	}
	
	public void updateAuthor(Author author){
		dao.beginTransaction();
		dao.updateAuthor(author);
		dao.commitTransaction();
	}
	
	public void removeAuthor(Author author){
		dao.beginTransaction();
		dao.removeAuthor(author);
		dao.commitTransaction();
	}
	
	
}
