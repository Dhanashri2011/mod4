

public class AuthorUI {

	public static void main(String[] args) {
		
		Author author = new Author();
		AuthorService servcie = new AuthorService();
		
		author.setFirstName("Dhanashri");
		author.setLastName("Sanase");
		author.setMiddleName("Anandrao");
		author.setPhoneNo("9876543210");
		
		//adding author
		servcie.addAuthor(author);
		
		//updating author
		author.setFirstName("Sayali");
		author.setLastName("Chavan");
		author.setMiddleName("Ram");
		author.setPhoneNo("0123456789");
		servcie.updateAuthor(author);
		
		//removing author
		servcie.removeAuthor(author);
		
		author.setFirstName("Dhanashri");
		author.setLastName("Sanase");
		author.setMiddleName("Anandrao");
		author.setPhoneNo("9876543210");
		
		//again adding author
		servcie.addAuthor(author);
		
		System.out.println("Added auhtor to database.");
	}
	
	
}
