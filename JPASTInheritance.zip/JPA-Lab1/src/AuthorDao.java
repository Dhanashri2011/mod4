import javax.persistence.EntityManager;



public class AuthorDao {
	
	private EntityManager em ;
	
	public AuthorDao() {
		em=AuthorUtil.getEntityManager();
	}
	
	public void addAuthor(Author author){
		em.persist(author);
	}
	
	public void updateAuthor(Author author){
		em.merge(author);
	}
	public void removeAuthor(Author author){
		em.remove(author);
	}
	
	public void beginTransaction() {
		em.getTransaction().begin();
	}

	public void commitTransaction() {
		em.getTransaction().commit();
	}
}
