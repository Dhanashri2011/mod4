import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class AuthorDao {

	private EntityManager entityManager;
	public AuthorDao() {
		entityManager = JpaUtil.getEntityManager();
	}
	
	public List<Book> getAllBooks() {
		String qry = "SELECT book FROM BOOK book";
		TypedQuery<Book> query = entityManager.createQuery(qry, Book.class);
		return query.getResultList();
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	public void addAuthor(Author author) {
		entityManager.persist(author);
	}
	

}
