import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class AuthorMain {
 public static void main(String[] args) {
	
	 AuthorDao dao = new AuthorDao();
	
	
	
	 Author author = new Author();
	 author.setFirstName("hgfgf");
	 author.setMiddleName("bvcc");
	 author.setLastName("hgf");
	 author.setPhoneNo("9876543210");
	 
	 Book book = new Book();
	 book.setPrice(320);
	 book.setTitle("kjhsfg");
	 
	 Book book2 = new Book();
	 book.setPrice(350);
	 book.setTitle("kjdsjghsfg");
	 
	 author.addBooks(book);
	 author.addBooks(book2);
	 
	
	dao.beginTransaction();
	dao.addAuthor(author);
	dao.commitTransaction();
	 
//	String qry = "SELECT book FROM BOOK book";
//	TypedQuery<Book> query = em.createQuery(qry, Book.class);
//	List<Book> listOfBooks = query.getResultList();
//
//	 System.out.println("Books and Authors added successfully");
//	 System.out.println(listOfBooks);
//	 em.close();
	
}
}
