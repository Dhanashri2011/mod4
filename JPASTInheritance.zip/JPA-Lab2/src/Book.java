import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Book {
	@Id
	@Column(name="Book_id", length=20)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bookId;
	@Column(name="Title" , length=20)
	private String title;
	@Column(name="Price" , length=20)
	private int price;
	
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="book")
	private Set<Author> authors = new HashSet<>();

	
	
	
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Set<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
	

	
}
