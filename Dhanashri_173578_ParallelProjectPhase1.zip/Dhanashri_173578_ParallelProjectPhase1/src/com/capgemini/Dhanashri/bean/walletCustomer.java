package com.capgemini.Dhanashri.bean;

public class walletCustomer {

	private String name;
	private String address;
	private String email;
	private int custId;
	private String mobNumber;
	private String walletBalance="00";
	private String lastdeposit;
	private String lastWithdrawal;
	private String lastFundTransfer;
	
	
	public String getWalletBalance() {
		return walletBalance;
	}
	
	public void setWalletBalance(String walletBalance) {
		this.walletBalance = walletBalance;
	}
	
	public String getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(String mobNumber) {
		this.mobNumber = mobNumber;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getLastdeposit() {
		return lastdeposit;
	}

	public void setLastdeposit(String lastdeposit) {
		this.lastdeposit = lastdeposit;
	}

	public String getLastWithdrawal() {
		return lastWithdrawal;
	}

	public void setLastWithdrawal(String lastWithdrawal) {
		this.lastWithdrawal = lastWithdrawal;
	}

	public String getLastFundTransfer() {
		return lastFundTransfer;
	}

	public void setLastFundTransfer(String lastFundTransfer) {
		this.lastFundTransfer = lastFundTransfer;
	}
	
}
