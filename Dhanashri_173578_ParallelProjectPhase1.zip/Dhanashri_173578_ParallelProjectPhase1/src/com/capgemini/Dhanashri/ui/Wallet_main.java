package com.capgemini.Dhanashri.ui;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.Dhanashri.bean.walletCustomer;
import com.capgemini.Dhanashri.dao.ResultNotFoundException;
import com.capgemini.Dhanashri.dao.WalletDao;
import com.capgemini.Dhanashri.functions.WalletFunctioanlity;
import com.capgemini.Dhanashri.service.WalletService;

public class Wallet_main {//class starts
	public static void main(String[] args) throws IOException,
			ResultNotFoundException, SQLException {//main starts
		Scanner scan = new Scanner(System.in);
		BufferedReader lineRead = new BufferedReader(new InputStreamReader(
				System.in));
		String choice;
		String name;
		String address;
		String email;
		String mobNumber;
		String walletBalance = "00";
		String deposit;
		String withdraw;
		String fund;
		int mainChoice;
		int findID;
		WalletService walletService = new WalletService();
		WalletDao dao = new WalletDao();
		WalletFunctioanlity wFunctions = new WalletFunctioanlity();
		

		System.out.println("Finance Company welcomes you to payment wallet!!!");
		while (true) {
			System.out.println("1. Register Customer  \n3. Exit \nEnter your choice(1/2): ");
			choice = scan.next();
			 if(walletService.validateChoice(choice)&& choice.equals("1"))
			 break; 
			 else if(walletService.validateChoice(choice)&& choice.equals("2")){
			 System.out.println("Thanks for visiting!!!"); System.exit(0); 
			 }
			 else System.out.println("You entered wrong input!");
		 }
	
			// registrations starts
			System.out.println("---------------Enter the following details for registration-------------");
			while (true) {
				System.out.println("Enter Customer Name: ");
				name = lineRead.readLine();
				if (walletService.validateName(name))
					break;
				else
					System.out.println("You entered invalid name!");
			}

			while (true) {
				System.out.println("Enter Address: ");
				address = lineRead.readLine();
				if (walletService.validateAddress(address))
					break;
				else
					System.out.println("You entered invalid Address!");
			}

			while (true) {
				System.out.println("Enter Email Address: ");
				email = scan.next();
				if (walletService.validateEmail(email))
					break;
				else
					System.out.println("You entered invalid Email Address!");
			}

			while (true) {
				System.out.println("Enter Mobile number: ");
				mobNumber = scan.next();
				if (walletService.validatemMbNumber(mobNumber))
					break;
				else
					System.out
							.println("You entered invalid Mobile number!\n Please enter 10 digits.");
			}
			walletCustomer customer = dao.createAccount(name, address, email,
				mobNumber, walletBalance);
			
					
					dao.storeIntoMap(customer);
			wFunctions.displayDetails(customer);			
			// registrations done

		
			System.out.println("Enter your Customer ID: ");
			findID = scan.nextInt();
			walletCustomer thisCustomer = dao.find(findID);
			
			while (true) { 
				System.out.println("-----------------------------------------------------------------------");
				System.out.println("1.Show Balance");
				System.out.println("2.Deposit money");
				System.out.println("3.Withdraw money");
				System.out.println("4.Fund Transfer");
				System.out.println("5.Print transactions");
				System.out.println("6.Exit");
				System.out.println("Enter choice: ");
				mainChoice = scan.nextInt();

				switch (mainChoice) {
				case 1:
					wFunctions.showbalance(thisCustomer);
					break;

				case 2:
					while (true) {
						System.out
								.println("Enter the amount you want to deposit: ");
						deposit = scan.next();
						if (walletService.validateDepositPattern(deposit))
							break;
						else
							System.out.println("You entered invalid amount!");
					}
					wFunctions.addDeposit(deposit, thisCustomer);
					thisCustomer.setLastdeposit(deposit);
					System.out.println("Rs." + deposit
							+ " added successfully to your wallet");
					wFunctions.showbalance(thisCustomer);
					// functions done
					break;

				case 3:
					while (true) {
						System.out
								.println("Enter the amount you want to withdraw: ");
						withdraw = scan.next();
						if (walletService.validateWithdrawPattern(withdraw))
							break;
						else
							System.out.println("You entered invalid amount!");
					}
					wFunctions.withdrawMoney(withdraw, thisCustomer);
					thisCustomer.setLastWithdrawal(withdraw);
					wFunctions.showbalance(thisCustomer);
					// functions done
					break;

				case 4:
					while (true) {
						System.out.println("Enter the fund amount you want to transfer: ");
						fund = scan.next();
						if (walletService.validateFundPattern(fund))
							break;
						else
							System.out.println("You entered invalid fund amount!");
					}
					wFunctions.transferFund(fund, thisCustomer);
					thisCustomer.setLastFundTransfer(fund);
					wFunctions.showbalance(thisCustomer);
					// functions done
					break;
				case 5:
					wFunctions.printTransaction(thisCustomer);
					break;

				case 6:
					System.out.println("Thanks for visiting!!!");
					break;

				default:
					System.out.println("Invalid choice");
					break;
				}// inner switch case closing
				// login done
			}// while loop closing of login		
	} // main method closing
} // class closing bracket
