package com.capgemini.Dhanashri.dao;


import java.util.Map;

import com.capgemini.Dhanashri.bean.walletCustomer;


public interface WalletDaoInterface {
	Map<Integer,walletCustomer> storeIntoMap(walletCustomer w);
	walletCustomer createAccount(String name,String address,String email,String mobNumber,String walletBalance);
	
	
}
