package com.capgemini.Dhanashri.functions;

import com.capgemini.Dhanashri.bean.walletCustomer;

public interface WalletFunctionalityInterface  {

	walletCustomer cust=new walletCustomer();
	void displayDetails(walletCustomer cust);
	void showbalance(walletCustomer cust);
	void addDeposit(String deposit, walletCustomer cust);
	void withdrawMoney(String withdrawAmmount, walletCustomer cust);
	void transferFund(String fund, walletCustomer cust);
	void printTransaction(walletCustomer cust);
	
}
