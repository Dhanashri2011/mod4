public class Shoes extends Product {
String size;
public Shoes(){}
public Shoes(String name, int price, int stock , String size) {
	super(name,  price, stock);
	this.size=size;
}

}