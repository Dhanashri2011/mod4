public class Watch extends Product{

	private String watchType;

	public Watch(String name, int price, int stock, String watchType) {
		super(name,  price, stock);
		this.watchType=watchType;
	}
	
}
