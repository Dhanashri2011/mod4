public abstract class Product {
private String name;
private double productCode;
private int price;
private int stock;	

public Product(){}
public void updateStock(int quantity ){
	stock+=quantity;
}
public Product(String name, int price, int stock) {
	super();
	this.name = name;
	this.productCode = productCode;
	this.price = price;
	this.stock = stock;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getProductCode() {
	return productCode;
}
public void setProductCode(double productCode) {
	this.productCode = productCode;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getStock() {
	return stock;
}
public void setStock(int stock) {
	this.stock = stock;
}
public void Display(int quantity ){
	System.out.println("Product name: " + name);
	System.out.println("Product code: " + productCode);
	System.out.println("Product price: " + price);
}
}
