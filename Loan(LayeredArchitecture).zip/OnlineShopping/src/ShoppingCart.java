import java.util.HashMap;
public class ShoppingCart {
	HashMap<Product, Integer> cart= new HashMap<>();
	double total;
	public ShoppingCart(){}
	public ShoppingCart(HashMap<Product, Integer> cart) {
		this.cart = cart;
	}	
	public void addItem(Product p , int qty) throws OutOfStockException{
		if(p.getStock()>=qty){
		cart.put(p,qty);
		p.updateStock(-qty );
		total+=p.getPrice()*qty;
		}
		else
			throw new OutOfStockException("You ordered " +qty + p.getName());
	}
	public void removeItem(Product p ){
		int qty=cart.get(p);
		p.updateStock(qty );
		total-=p.getPrice()*qty;
	}	
	public void checkOut(){
		System.out.println("--------Shopping cart------");
	for (Product p:cart.keySet()){
		int qty=cart.get(p);
		System.out.println("Number of ordered items: " + qty);
		System.out.println("Price of ordered items: " + total);
	}
	}
	
}
