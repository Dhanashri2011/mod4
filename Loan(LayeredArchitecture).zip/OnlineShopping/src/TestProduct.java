public class TestProduct {
public static void main(String[] args) {
		ShoppingCart amazon= new ShoppingCart();
				
				Shoes s1=new Shoes("Nike" , 2400 , 2,"L");
				Watch w1 = new Watch("G-Shock ", 6500 , 5, "Chrono");
				
		try{
			amazon.addItem(s1,1);
		}
		catch(OutOfStockException e){
			System.out.println(e.getMessage());
		}
		try{
			amazon.addItem(w1,2);
		}
		catch(OutOfStockException e){
			System.out.println(e.getMessage());
		}
		
		amazon.checkOut();
}
}
