package com.capgemini.Dhanashri.dao;


import java.util.Map;

import com.capgemini.Dhanashri.bean.walletCustomer;


public interface WalletDaoInterface {
	

	
	Map<Integer,walletCustomer> storeIntoMap(walletCustomer w);
	
	walletCustomer createAccount(String name,String address,String email,String mobNumber,String walletBalance);
	
	void deposit(int accID, double amount) throws ResultNotFoundException;

	double showBalance1(int userAccId) throws ResultNotFoundException;


	void insertDetails(int accId, String type, String deposit, String string);

	void insertDetails(int accId, String type, double amount, double d);	
	
	void displayDetails(walletCustomer cust);
	void showbalance(walletCustomer cust);
	void addDeposit(String deposit, walletCustomer cust);
	void withdrawMoney(String withdrawAmmount, walletCustomer cust);
	void transferFund(String fund, walletCustomer cust);
	void printTransaction(walletCustomer cust) throws ResultNotFoundException;
	
}