package com.capgemini.Dhanashri.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.Dhanashri.JDBC.JdbcUtilConn;
import com.capgemini.Dhanashri.bean.Transaction;
import com.capgemini.Dhanashri.bean.walletCustomer;

public class WalletDao implements WalletDaoInterface {
	

	
	walletCustomer cust = new walletCustomer();
	private Map<Integer, walletCustomer> info = new HashMap<Integer, walletCustomer>();
	Connection connection = null;
	PreparedStatement statement = null;
	private ArrayList<Transaction> transactionArr = null;
	
	@Override
	public Map<Integer, walletCustomer> storeIntoMap(walletCustomer w) {

		
		info.put(w.getCustId(), w);
		return info;
	}
	
	public walletCustomer find(int custId) throws ResultNotFoundException {
		cust = info.get(custId);
		if (cust != null)
			return cust;
		else
			throw new ResultNotFoundException(
					"This Customer ID does not exist!");
	}

	

	
	@Override
	public walletCustomer createAccount(String name, String address,
			
			String email, String mobNumber, String walletBalance) {
		
		cust.setName(name);
		cust.setAddress(address);
		cust.setEmail(email);
		cust.setMobNumber(mobNumber);
		cust.setWalletBalance(walletBalance);
		cust.setCustId(((int)((Math.random()*1000)+1)));
		storeIntoMap(cust);
		System.out.println("---------------------Details Saved Successfully!!!--------------------\n");
		return cust;
	}

	@Override
	public void insertDetails(int accId, String type, String deposit,
			String string) {
		connection = JdbcUtilConn.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.transaction);
			statement.setInt(1, accId);
			statement.setString(3, deposit);
			statement.setString(2, type);
			statement.setString(4, string);
			statement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	
	
	
	@Override
	public double showBalance1(int userAccId) throws ResultNotFoundException {
		connection = JdbcUtilConn.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.showbalance);
			//passing user input
			statement.setInt(1, userAccId);
			ResultSet set = statement.executeQuery();
			if (set.next()) {
				//fetching balance from table
				return set.getDouble("Balance");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		throw new ResultNotFoundException(
				"Accound Record not found.\nFirst Open Account");
	}
	
	@Override
	public void deposit(int accID, double amount)
			throws ResultNotFoundException {
		connection = JdbcUtilConn.getConnection();
		double balance = showBalance1(accID);
		if (balance >= 0) {
			try {
				statement = connection.prepareStatement(QueryMapper.deposite);
				//inserting details to deposit
				statement.setInt(2, accID);
				statement.executeUpdate();
				//passing all details in transaction table
				insertDetails(accID, "CR", amount, amount + balance);

			} catch (SQLException e) {
				throw new ResultNotFoundException(
						"Accound Record not found.\nFirst Open Account");
			}

		} else
			throw new ResultNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	
}

	@Override
	public void insertDetails(int accId, String type, double amount, double d) {
		// TODO Auto-generated method stub
		
	}


	
	@Override
	public void displayDetails(walletCustomer w) {
		System.out.println("Account created successfully!!!");
		System.out.println("Name: " + w.getName() + "\nAddress: " + w.getAddress() + 
				"\nEmail address: " + w.getEmail()+"\nMobile number: " + w.getMobNumber()+ 
				"\nCustomer ID: " + w.getCustId() + "\nWallet balance: " + w.getWalletBalance()+"\n");	
	}

	@Override
	public void showbalance(walletCustomer cust) {
		System.out.println("Your wallet balance is: " + cust.getWalletBalance());
	}

	@Override
	public void addDeposit(String deposit, walletCustomer cust) {
		int temp = Integer.parseInt(cust.getWalletBalance()) + Integer.parseInt(deposit);
		cust.setWalletBalance(Integer.toString(temp));
		transactionArr= new ArrayList<Transaction>();
		transactionArr.add(new Transaction("Credited",Integer.parseInt(deposit), temp));
	}

	@Override
	public void withdrawMoney(String withdrawAmmount, walletCustomer cust) {
		int temp = Integer.parseInt(cust.getWalletBalance()) - Integer.parseInt(withdrawAmmount);
		if(temp<0)
			System.out.println("Your wallet balance is less than "+ withdrawAmmount + "\nCannot withdraw money.\n");
		else{
			cust.setWalletBalance(Integer.toString(temp));
		System.out.println("Rs."+ withdrawAmmount+ " withdrawn successfully from your wallet  " + "\n");
		transactionArr= new ArrayList<Transaction>();
		transactionArr.add(new Transaction("WithDrawal",Integer.parseInt(withdrawAmmount), temp));
		}
	}

	@Override
	public void transferFund(String fund, walletCustomer cust) {
		int temp = Integer.parseInt(cust.getWalletBalance()) - Integer.parseInt(fund);
		if(temp<0)
			System.out.println("Your wallet balance is less than "+ fund);
		else{
			cust.setWalletBalance(Integer.toString(temp));	
		System.out.println("Rs."+ fund+ " transferred successfully from your wallet" + "\n");
		transactionArr= new ArrayList<Transaction>();
		transactionArr.add(new Transaction("WithDrawal",Integer.parseInt(fund), temp));
		}
	}

	@Override
	public void printTransaction(walletCustomer cust) throws ResultNotFoundException {
		if(transactionArr!=null){
			for (Transaction transaction : transactionArr) {
				System.out.println(transaction.print());
			}
		}
		else
		throw new ResultNotFoundException("Accound Record not found.\nFirst Open Account");
	}

}
