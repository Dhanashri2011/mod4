package com.capgemini.Dhanashri.dao;
public class ResultNotFoundException extends Exception{

	
	public ResultNotFoundException() {
		super();
		
	}

	public ResultNotFoundException(String arg0) {
		super(arg0);
	}
	

}

