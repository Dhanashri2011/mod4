package com.capgemini.Dhanashri.dao;

public interface QueryMapper {
public String insertDetails="insert into bank values(seq_accno.nextval,?,?,?,?)";
	
	String sql= "Select * from bankaccount where ACC_NO=?";
	
	String details="select * from bank where accno=(select max(accno)from bank)";
	
	String showbalance="select balance from bank where accno=?";
	
	String withdraw="update bank set balance=balance-? where accno=?";
	
	String deposite="update bank set balance=balance+? where accno=?";
	
	String transaction = "insert into transaction values(seq_trans.nextval,?,?,?,?)";
	
	String show = "select * from transaction where accno=? order by id";
}
