package com.capgemini.Dhanashri.bean;

public class Transaction {

	String type;
	int  amount;
	double balance;
	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	
	public Transaction(String type, int amount, double balance) {
		super();
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	public String print() {
		return (type + "\t" + amount + "\t" + balance);
	}
	
}
