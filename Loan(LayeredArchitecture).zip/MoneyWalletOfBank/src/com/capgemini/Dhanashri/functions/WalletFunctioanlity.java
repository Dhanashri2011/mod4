package com.capgemini.Dhanashri.functions;

import java.util.ArrayList;

import com.capgemini.Dhanashri.bean.Transaction;
import com.capgemini.Dhanashri.bean.walletCustomer;
import com.capgemini.Dhanashri.dao.ResultNotFoundException;

public class WalletFunctioanlity implements WalletFunctionalityInterface {

	private ArrayList<Transaction> transactionArr = null;
	
	@Override
	public void displayDetails(walletCustomer w) {
		System.out.println("Account created successfully!!!");
		System.out.println("Name: " + w.getName() + "\nAddress: " + w.getAddress() + 
				"\nEmail address: " + w.getEmail()+"\nMobile number: " + w.getMobNumber()+ 
				"\nCustomer ID: " + w.getCustId() + "\nWallet balance: " + w.getWalletBalance()+"\n");	
	}

	@Override
	public void showbalance(walletCustomer cust) {
		System.out.println("Your wallet balance is: " + cust.getWalletBalance());
	}

	@Override
	public void addDeposit(String deposit, walletCustomer cust) {
		int temp = Integer.parseInt(cust.getWalletBalance()) + Integer.parseInt(deposit);
		cust.setWalletBalance(Integer.toString(temp));
		transactionArr= new ArrayList<Transaction>();
		transactionArr.add(new Transaction("Credited",Integer.parseInt(deposit), temp));
	}

	@Override
	public void withdrawMoney(String withdrawAmmount, walletCustomer cust) {
		int temp = Integer.parseInt(cust.getWalletBalance()) - Integer.parseInt(withdrawAmmount);
		if(temp<0)
			System.out.println("Your wallet balance is less than "+ withdrawAmmount + "\nCannot withdraw money.\n");
		else{
			cust.setWalletBalance(Integer.toString(temp));
		System.out.println("Rs."+ withdrawAmmount+ " withdrawn successfully from your wallet  " + "\n");
		transactionArr= new ArrayList<Transaction>();
		transactionArr.add(new Transaction("WithDrawal",Integer.parseInt(withdrawAmmount), temp));
		}
	}

	@Override
	public void transferFund(String fund, walletCustomer cust) {
		int temp = Integer.parseInt(cust.getWalletBalance()) - Integer.parseInt(fund);
		if(temp<0)
			System.out.println("Your wallet balance is less than "+ fund);
		else{
			cust.setWalletBalance(Integer.toString(temp));	
		System.out.println("Rs."+ fund+ " transferred successfully from your wallet" + "\n");
		transactionArr= new ArrayList<Transaction>();
		transactionArr.add(new Transaction("WithDrawal",Integer.parseInt(fund), temp));
		}
	}

	@Override
	public void printTransaction(walletCustomer cust) throws ResultNotFoundException {
		if(transactionArr!=null){
			for (Transaction transaction : transactionArr) {
				System.out.println(transaction.print());
			}
		}
		else
		throw new ResultNotFoundException("Accound Record not found.\nFirst Open Account");
	}
}
