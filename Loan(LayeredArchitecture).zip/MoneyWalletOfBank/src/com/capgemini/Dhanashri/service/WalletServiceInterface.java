package com.capgemini.Dhanashri.service;

import java.util.Map;

import com.capgemini.Dhanashri.bean.walletCustomer;
import com.capgemini.Dhanashri.dao.ResultNotFoundException;

public interface WalletServiceInterface {
	String choicePattern="[1-2]{1}";
	String namePattern= "[A-Z]{1}[A-z]{1,50}";
	String addressPattern = "[A-Z]{1}[A-z]{1,50}";
	String emailPattern= "[a-zA-Z]{1,25}[@]{1}[A-z]{1,10}[.]{1}[c,o,m]{3}";
	String mobNumPattern="[0-9]{10}";
	String depositChoicePattern="[1-2]{1}";
	String withdrawChoicePattern="[1-2]{1}";
	String fundTransferChoicePattern="[1-2]{1}";
	String printTransactionChoicePattern = "[1-2]{1}";	
	String walletBalancePattern="[0-9]{1,10}" ;
	String depositPattern="[0-9]{1,10}";
	String withdrawPattern="[0-9]{1,10}";
	String fundPattern="[0-9]{1,10}";
	
	
	public boolean validateChoice(String n);
	public boolean validateName(String n);
	public boolean validateAddress(String n);
	public boolean validateEmail(String n);
	public boolean validatemMbNumber(String n);
	public boolean validatedepositChoice(String n);
	public boolean validateWithdrawChoice(String n);
	public boolean validateFundTransferChoice(String n);
	public boolean validatePrintTransactionChoice(String n);	
	public boolean validateWalletBalancePattern(String n);
	public boolean validateDepositPattern(String n);
	public boolean validateWithdrawPattern(String n);
	public boolean validateFundPattern(String n);

	public Map<Integer, walletCustomer> storeIntoMap(walletCustomer w);
	public walletCustomer find(int custId) throws ResultNotFoundException ;
	public walletCustomer createAccount(String name, String address,String email, String mobNumber, String walletBalance);
	
}
