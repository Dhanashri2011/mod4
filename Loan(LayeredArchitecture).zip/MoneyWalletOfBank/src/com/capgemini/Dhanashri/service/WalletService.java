package com.capgemini.Dhanashri.service;
import java.util.Map;

import com.capgemini.Dhanashri.bean.walletCustomer;
import com.capgemini.Dhanashri.dao.ResultNotFoundException;
import com.capgemini.Dhanashri.dao.WalletDao;


public class WalletService implements WalletServiceInterface {

	WalletDao dao=new WalletDao();
	
	@Override
	public Map<Integer, walletCustomer> storeIntoMap(walletCustomer w) {
		return dao.storeIntoMap(w);
	}
	
	@Override
	public walletCustomer find(int custId) throws ResultNotFoundException {
		return dao.find(custId);
	}

	@Override
	public walletCustomer createAccount(String name, String address,String email, String mobNumber, String walletBalance) {
		
		return dao.createAccount(name, address, email, mobNumber, walletBalance);
	}
	
	
	
	@Override
	public boolean validateChoice(String n) {
		return n.matches(choicePattern);
	}

	@Override
	public boolean validateName(String n) {
		return n.matches(namePattern);
	}

	@Override
	public boolean validateAddress(String n) {
		return n.matches(addressPattern);
	}

	@Override
	public boolean validateEmail(String n) {
		return n.matches(emailPattern);
	}
	
	@Override
	public boolean validatemMbNumber(String n) {
		return n.matches(mobNumPattern);
	}

	@Override
	public boolean validatedepositChoice(String n) {
		return n.matches(depositChoicePattern);
	}

	@Override
	public boolean validateWithdrawChoice(String n) {
		return n.matches(withdrawChoicePattern);
	}

	@Override
	public boolean validateFundTransferChoice(String n) {
		return n.matches(fundTransferChoicePattern);
	}

	@Override
	public boolean validatePrintTransactionChoice(String n) {
		return n.matches(printTransactionChoicePattern);
	}

	@Override
	public boolean validateWalletBalancePattern(String n) {
		return n.matches(walletBalancePattern);
	}

	@Override
	public boolean validateDepositPattern(String n) {
		return n.matches(depositPattern);
	}

	@Override
	public boolean validateWithdrawPattern(String n) {
		return n.matches(withdrawPattern);
	}

	@Override
	public boolean validateFundPattern(String n) {
		return n.matches(fundPattern);
	}
	
	

	



}
