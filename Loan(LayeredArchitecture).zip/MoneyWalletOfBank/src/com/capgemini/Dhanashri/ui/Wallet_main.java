package com.capgemini.Dhanashri.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.Dhanashri.bean.walletCustomer;
import com.capgemini.Dhanashri.dao.ResultNotFoundException;
import com.capgemini.Dhanashri.dao.WalletDao;
import com.capgemini.Dhanashri.functions.WalletFunctioanlity;
import com.capgemini.Dhanashri.service.WalletService;

public class Wallet_main {//class starts
	public static void main(String[] args) throws IOException,
			ResultNotFoundException, ClassNotFoundException {//main starts
		Scanner scan = new Scanner(System.in);
		BufferedReader lineRead = new BufferedReader(new InputStreamReader(
				System.in));
		String choice;
		String name;
		String address;
		String email;
		String mobNumber;
		String walletBalance = "00";
		String deposit;
		String withdraw;
		String fund;
		int mainChoice;
		int findID;
		WalletService walletService = new WalletService();
		WalletDao dao=new WalletDao();

		
		System.out.println("Finance Company welcomes you to payment wallet!!!");
		while (true) {
			System.out.println("1. Register Customer  \n3. Exit \nEnter your choice(1/2): ");
			choice = scan.next();
			 if(walletService.validateChoice(choice)&& choice.equals("1"))
			 break; 
			 else if(walletService.validateChoice(choice)&& choice.equals("2")){
			 System.out.println("Thanks for visiting!!!"); System.exit(0); 
			 }
			 else System.out.println("You entered wrong input!");
		 }
	
			// registrations starts
			System.out.println("---------------Enter the following details for registration-------------");
			while (true) {
				System.out.println("Enter Customer Name: ");
				name = lineRead.readLine();
				if (walletService.validateName(name))
					break;
				else
					System.out.println("You entered invalid name!");
			}

			while (true) {
				System.out.println("Enter Address: ");
				address = lineRead.readLine();
				if (walletService.validateAddress(address))
					break;
				else
					System.out.println("You entered invalid Address!");
			}

			while (true) {
				System.out.println("Enter Email Address: ");
				email = scan.next();
				if (walletService.validateEmail(email))
					break;
				else
					System.out.println("You entered invalid Email Address!");
			}

			while (true) {
				System.out.println("Enter Mobile number: ");
				mobNumber = scan.next();
				if (walletService.validatemMbNumber(mobNumber))
					break;
				else
					System.out
							.println("You entered invalid Mobile number!\n Please enter 10 digits.");
			}
			walletCustomer customer = walletService.createAccount(name, address, email,
				mobNumber, walletBalance);
			
					
		//	walletService.storeIntoMap(customer);
			
			customer.setWalletBalance("00");
			dao.displayDetails(customer);			
			// registrations done

		
			System.out.println("Enter your Customer ID: ");
			findID = scan.nextInt();
			walletCustomer thisCustomer = walletService.find(findID);
			
			while (true) { 
				System.out.println("-----------------------------------------------------------------------");
				System.out.println("1.Show Balance");
				System.out.println("2.Deposit money");
				System.out.println("3.Withdraw money");
				System.out.println("4.Fund Transfer");
				System.out.println("5.Print transactions");
				System.out.println("6.Exit");
				System.out.println("Enter choice: ");
				mainChoice = scan.nextInt();

				switch (mainChoice) {
				case 1:
					dao.showbalance(thisCustomer);
					break;

				case 2:
					while (true) {
						System.out
								.println("Enter the amount you want to deposit: ");
						deposit = scan.next();
						if (walletService.validateDepositPattern(deposit))
							break;
						else
							System.out.println("You entered invalid amount!");
					}
					dao.addDeposit(deposit, thisCustomer);
				
					System.out.println("Rs." + deposit
							+ " added successfully to your wallet");
					//wFunctions.showbalance(thisCustomer);
					dao.insertDetails(customer.getCustId() ,  "Saving",deposit , thisCustomer.getWalletBalance());//store into sql table
					// functions done
					break;

				case 3:
					while (true) {
						System.out
								.println("Enter the amount you want to withdraw: ");
						withdraw = scan.next();
						if (walletService.validateWithdrawPattern(withdraw))
							break;
						else
							System.out.println("You entered invalid amount!");
					}
					dao.withdrawMoney(withdraw, thisCustomer);
					
					dao.showbalance(thisCustomer);
					// functions done
					break;

				case 4:
					while (true) {
						System.out.println("Enter the fund amount you want to transfer: ");
						fund = scan.next();
						if (walletService.validateFundPattern(fund))
							break;
						else
							System.out.println("You entered invalid fund amount!");
					}
					dao.transferFund(fund, thisCustomer);
					
					dao.showbalance(thisCustomer);
					// functions done
					break;
				case 5:
					dao.printTransaction(thisCustomer);
					break;

				case 6:
					System.out.println("Thanks for visiting!!!");
					break;

				default:
					System.out.println("Invalid choice");
					break;
				}// inner switch case closing
				// login done
			}// while loop closing of login		
	} // main method closing
} // class closing bracket
