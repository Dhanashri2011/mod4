public class Parent {
	private int num1;

	public void parentMethod(int num) {
		System.out.println("Parent method");

	}
public Parent() {
	// TODO Auto-generated constructor stub
}

	public Parent(int num1) {
		this.num1 = num1;
	}

}