
public class Child extends Parent {
	
	
	public Child(int num1) {
		super(num1);
	}


	public Child() {
		// TODO Auto-generated constructor stub
	}

	public void childMethod() {
		System.out.println("Child method");
	}
	
	@Override
	public void parentMethod(int num) {
		System.out.println("Parent method");

	}
	
}
