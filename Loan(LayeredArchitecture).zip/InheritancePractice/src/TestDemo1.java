
public class TestDemo1 {
	public static void main(String[] args) {
		
		
		/*int arr[];
		arr=new int[10];*/
		
	/*	int[] arr=new int[10]; */
		
		int arr[];
		String newArr[]= {"fmhg","jhfdsg"};
		System.out.println(newArr[1]);
		System.out.println(arr);
		
	
	//	Parent objP=new Parent(1);
//		Parent p1 = null;
		
		//Child c1= (Child) objP;
		
	/*	Child objC= new Child(1);
		
		Parent p2= objC;*/
		
		
		
		Parent p2= new Child(1);
		((Child) p2).childMethod();
		
	/*	objP.parentMethod(1);
		objC.parentMethod(1);
		
		objC.childMethod();
		((Child) objP).childMethod();*/
	
		
		Child c1=new Child();
		 c1.parentMethod(1);
	}

}
