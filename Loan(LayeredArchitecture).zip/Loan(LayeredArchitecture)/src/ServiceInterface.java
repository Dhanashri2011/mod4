import java.util.Map;


public interface ServiceInterface {

	String namePattern= "[A-Za-z]{1,20}";
	String addressPattern = "[A-Za-z]{1,50}";
	String emailPattern= "[a-zA-Z]{1,25}[@]{1}[a-z]{1,10}[.]{1}[c,o,m]{3}";
	String choicePattern="[1-2]{1}";
	String loanChoicePattern="[y,n]{1}";
	String loanDurationPattern = "[0-9]{0,2}";
	String loanAmountPattern = "[0-9]{0,10}";
	
	
	
	public boolean validateChoice(String n);
	public boolean validateName(String n);
	public boolean validateAddress(String n);
	public boolean validateEmail(String n);
	public boolean validateLoanChoice(String n);
	public boolean validateLoanDuration(String n);
	public boolean validateLoanAmount(String n);

	
	public void storeIntoSet(Customer customer);
	public void applyLoan(String loanAmount, String loanDuration,
			Customer customer);
	public double calculateEMI(String amount,String duration);
	public void displayCust(Customer customer);
}
