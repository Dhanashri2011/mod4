import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Service service = new Service();
	Customer customer=new Customer();

	
	Scanner scan= new Scanner(System.in);
	String choice;
	String name;
	String address;
	String email;
	String loanChoice;
	String loanDuration;
	String loanAmount;
	
	
	System.out.println("Finance Company welcomes you!!!");	
	while(true){
		System.out.println("1.	Register Customer \n2.	Exit");
		choice=scan.next();
		if(service.validateChoice(choice)&& choice.equals("1"))
			break;
		else if(service.validateChoice(choice)&& choice.equals("2")){
			System.out.println("Thanks for visiting");
			System.exit(0);
			}
	}
	System.out.println("----------Enter the following details for registration------------");
	while(true){
		System.out.println("Enter Customer Name: ");
		name = scan.next();
		if(service.validateName(name))
			break;
		else
			System.out.println("Please enter valid name!");
	}

	while(true){
		System.out.println("Enter Address: ");
		address= scan.next();
		if(service.validateAddress(address))
			break;
		else
			System.out.println("Please enter valid address!");
	}
	while(true){
		System.out.println("Enter Email Address: ");
		email= scan.next();
		if(service.validateEmail(email))
			break;
		else
			System.out.println("Please enter valid email address!");
	}
	customer.setChoice(choice);
	customer.setName(name);
	customer.setAddress(address);
	customer.setEmail(email);
	int c_id=(int)Math.random()*100;
	customer.setCustId(Integer.toString(c_id));
	service.storeIntoSet(customer);
	System.out.println("Customer details saved successfully!");
	service.displayCust(customer);
	
	while(true){
		System.out.println("Do you wish to apply for Loan? (y/n)");
		loanChoice= scan.next();
		if(service.validateLoanChoice(loanChoice) && loanChoice.equals("y"))
			break;
		else if(service.validateLoanChoice(loanChoice) && loanChoice.equals("n")){
		System.out.println("Successfully exited!");
		System.exit(0);
		}
		else
			System.out.println("Please enter y or n");	
	}
	
	
	while(true){
		System.out.println("Enter the loan amount:");
		loanAmount= scan.next();
		if(service.validateLoanAmount(loanAmount))
			break;
		else
			System.out.println("Please enter valid amount");	
	}
	while(true){
		System.out.println("Enter the loan duration (In year):");
		loanDuration= scan.next();
		if(service.validateLoanDuration(loanDuration))
			break;
		else
			System.out.println("Please enter valid duration!");	
	}
	service.calculateEMI( loanAmount, loanDuration);
	service.applyLoan( loanAmount, loanDuration, customer);
	System.out.println("Applied for loan successfully!");
	
	
	
}
}
