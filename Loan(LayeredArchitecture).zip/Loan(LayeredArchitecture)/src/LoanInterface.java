
public interface LoanInterface {

	
	public double calculateEMI(String amount,String duration);
	public Loan setLoan(String amount,String duration,  Customer cust);
	
}
