import java.util.Set;


public interface DaoInterfce {
	public void insertCust(Customer customer);
	public void addLoan (Loan loan);
	public void displayCust(Customer customer);
}
