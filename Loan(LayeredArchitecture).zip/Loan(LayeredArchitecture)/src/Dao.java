import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


public class Dao implements DaoInterfce {
	
	
	Set<Customer> custDetails = new HashSet<Customer>();
	Set<Loan> loanDetails = new HashSet<Loan>();

	@Override
	public void insertCust(Customer customer) {
		custDetails.add(customer);
	}

	@Override
	public void addLoan(Loan loan) {
		loanDetails.add(loan);
		}
	
	@Override
	public void displayCust(Customer customer) {
		Iterator it= custDetails.iterator();
		while (it.hasNext())
		{
			System.out.println(it.next());
		}
	}

}
