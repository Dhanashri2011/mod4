
public class LoanService implements LoanInterface {

	Loan loan = new Loan();
	Dao dao=new Dao();
	


	@Override
	public double calculateEMI(String loanAmount, String loanDuration) {
		double noOfMonths= (double)(Integer.parseInt(loanDuration))*12;
		double interest=loan.interest;
		double loanAmnt= (double)(Integer.parseInt(loanAmount));
		double rate=interest/(12*100);
		double emi=Math.round(loanAmnt*rate*Math.pow(1+rate, noOfMonths/Math.pow(1+rate, noOfMonths-2)));
				
				//(long) (loanAmnt * loan.interest *(1 + loan.interest)*noOfMonths/ ((1 + loan.interest)*noOfMonths - 1));
		loan.setEmi(emi);
		return loan.getEmi();
	}



	@Override
	public Loan setLoan(String amount, String duration, Customer cust) {
		loan.setEmi(calculateEMI(amount, duration));
		loan.setCustId(cust.getCustId());
		loan.setDuration(duration);
		loan.setLoanAmount(amount);
		loan.setLoanID((Math.random()*100));
		return loan;	
	}
	
	
}

