
public class Customer {

	private String choice;
	private String name;
	private String address;
	private String email;
	private String custId;
	
	
	
	@Override
	public String toString() {
		return "Customer [choice=" + choice + ", name=" + name + ", address="
				+ address + ", email=" + email + ", custId=" + custId + "]";
	}
	public String getChoice() {
		return choice;
	}
	public void setChoice(String choice) {
		this.choice = choice;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	

}
