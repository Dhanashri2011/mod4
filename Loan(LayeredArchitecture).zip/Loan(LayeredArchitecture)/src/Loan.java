
public class Loan {
	private double loanID;
	private String loanAmount;
	private String custId;
	private String duration;
	private double emi;
	double interest= 9.5;
	
	public double getEmi() {
		return emi;
	}
	public void setEmi(double emi) {
		this.emi = emi;
	}
	public double getLoanID() {
		return loanID;
	}
	public void setLoanID(double d) {
		this.loanID = d;
	}
	public String getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(String amount) {
		this.loanAmount = amount;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String string) {
		this.custId = string;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration2) {
		this.duration = duration2;
	}
	
	
}
