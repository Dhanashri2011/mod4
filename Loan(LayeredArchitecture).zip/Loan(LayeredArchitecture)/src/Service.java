import java.util.HashMap;
import java.util.Map;


public class Service implements ServiceInterface {
	
	Dao dao = new Dao();
	LoanService loanService = new LoanService();
	
	@Override
	public void storeIntoSet(Customer customer) {
		dao.insertCust(customer);
	}

	@Override
	public boolean validateChoice(String n) {
		return n.matches(choicePattern);

	}

	@Override
	public boolean validateName(String n) {
		return n.matches(namePattern);
	}

	@Override
	public boolean validateAddress(String n) {
		return n.matches(addressPattern);
	}

	@Override
	public boolean validateEmail(String n) {
		return n.matches(emailPattern);
	}

	@Override
	public boolean validateLoanChoice(String n) {
		return n.matches(loanChoicePattern);
	}

	@Override
	public boolean validateLoanDuration(String n) {
		return n.matches(loanDurationPattern);
	}

	public boolean validateLoanAmount(String n) {
		return n.matches(loanAmountPattern);
	}

	
	
	@Override
	public double calculateEMI(String amount, String duration) {
		return loanService.calculateEMI(amount, duration);
	}

	public void applyLoan(String loanAmount, String loanDuration,
			Customer customer) {
		loanService.setLoan(loanAmount, loanDuration, customer);
		dao.addLoan(loanService.setLoan(loanAmount, loanDuration, customer));
	}

	@Override
	public void displayCust(Customer customer) {
		dao.displayCust(customer);
	}

	
	
	
}
