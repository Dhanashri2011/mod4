str = "University at Capgemini";

match= str.match("Capgemini");

substr= str.substr(3,6);

var sentence="Hello JavaScripters";
	
lowerSentence= sentence.toLowerCase();

upperSentence= sentence.toUpperCase();