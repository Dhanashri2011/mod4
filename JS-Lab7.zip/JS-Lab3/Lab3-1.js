

dt = new Date();
hour = dt.getHours();

function dispMsg(){
	if(hour<12)
		document.write("<h1><br>Good morning");
	if(hour>= 12 && hour<= 17)
		document.write("<h1><br>Good afternoon");
	if (hour>17)
		document.write("<h1><br>Good evening");		
}