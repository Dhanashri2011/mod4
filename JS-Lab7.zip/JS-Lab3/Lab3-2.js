
string = "Capgemini";
character = "p";

function findIndex() {
	index = string.indexOf(character);
	return index;
}
