	function dynamicdropdown(indexname){
			
			switch (indexname)
	        {
	        case "electronics" :
	            document.getElementById("products").options[0]=new Option("Select Product","");
	            document.getElementById("products").options[1]=new Option("Television","20000");
	            document.getElementById("products").options[2]=new Option("Laptop","30000");
	            document.getElementById("products").options[3]=new Option("Phone","10000");
	            break;
	        case "grocery" :
	            document.getElementById("products").options[0]=new Option("Select Product","");
	            document.getElementById("products").options[1]=new Option("Soap","40");
	            document.getElementById("products").options[2]=new Option("Powder","90");
	            break;
	        case "select" :
	            document.getElementById("products").options[0]=new Option("Select Product","");
	        return true;
		}
		
		}
		function getprice(){
			var t_menu=document.getElementById("products");
			var value=t_menu.options[t_menu.selectedIndex].value;
			var qty=document.getElementById("quantity").value;
			console.log("valu="+value+" qty="+qty);
			document.getElementById("totalPrice").value=parseInt(qty)*parseInt(value);
		}