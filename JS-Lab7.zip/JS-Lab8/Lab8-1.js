
function compute(){
	 var amt = document.getElementById("loanAmount").value;
	 var yr = document.getElementById("period").value;
	 var perc = document.getElementById("interestRate").value;
	 
	 if(amt>1500000){
		 alert("Loan amount should not exceed  Rs.1500000");
	 }
	 
	 if(yr<=7 && yr>=15){
		 alert("Repayment period should not be more than 7 and exceeded by 15");
		 return null;
	 }
	 
	 var monpay = (amt * Math.pow((1+(perc/100)),yr)) - amt;
	 
	 document.getElementById("monpay").value =Math.round(monpay);
	 
	 document.getElementById("totpay").value = amt;
	 
	 document.getElementById("intpay").value = perc;
}