
array=new Array("Dhanashri" , "Rishi" , "Sushen" , "Shreya" , "Varsha" );

function disparray(){
	document.write("<h1>List of employees : <br><br></h1>");
	for(i=0;i<=5;i++){
		document.write(array[i]+"<br><br>");
	}
}