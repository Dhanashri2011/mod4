
 var x = location.href;
 
 var y = location.pathname;
 
 var z = location.protocol;