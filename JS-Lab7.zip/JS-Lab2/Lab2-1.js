function doWhileLoop(){
	
	var row=1;
	var col=1;
	var numOfRows;
	
	for(numOfRows=1;numOfRows<11;numOfRows++)
	{
		
	do{
		document.write(row + " ");
		row++;
		col++;
	}
	while(col<=10)
		document.write("<br>");
		col=1;
	}
}