

function calculateinterest(){
	var p = document.getElementById("principle").value;
	var r = document.getElementById("interest").value;
	var n = document.getElementById("period").value;
	var compoundInterest= ((p* Math.pow( (1+(r/100)),n)) - p);
	document.write("<h>Compound interest is </h>" + Math.round(compoundInterest));
}