
var msg;
msg="<p><code>The actual script is in external script file called lab1.js</code></p>";
var sum;

function sayHello()
{
  document.write("Hello! Lab 1.3 ");
}

function dispHello()
{
return document.write("Hello! Lab 1.4 ");
}

function addNos(headvar,bodyvar)
{
sum= headvar+bodyvar;
return sum;
}
