function invoice() {
	
	 dollQty = document.getElementById("qty1").value;
	 calcQty = document.getElementById("qty2").value;
	 mobileQty = document.getElementById("qty3").value;
	 discQty = document.getElementById("qty4").value;



	if (dollQty == "" && calcQty == "" && mobileQty == "" && discQty == "") {
		alert("no item selected");
		return null;
		}
	else 
		{
		newwindow = window.open('', '', 'width=500,height=300,left=300,top=200');
		newwindow.document.write("<h2 align='center'>INVOICE</h2>");
		newwindow.document.write("<table border='1' align='center' >");
		newwindow.document
		.write("<tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th></tr>");
		
		if(dollQty!="")
			newwindow.document
			.write("<tr><td>Barbie Doll</td><td>"+dollQty +"</td><td>20</td><td>"+ (dollQty*20 )+"</td></tr>");
		
		if(calcQty!="")
			newwindow.document
			.write("<tr><td>Calculator</td><td>"+calcQty +"</td><td>20</td><td>"+ (calcQty*30 )+"</td></tr>");
		
		if(mobileQty!="")
			newwindow.document
			.write("<tr><td>Mobile phone</td><td>"+mobileQty + "</td><td>20</td><td>"+ (mobileQty*40 )+"</td></tr>");
		
		if(discQty!="")
			newwindow.document
			.write("<tr><td>LG DVD</td><td>"+discQty +"</td><td>20</td><td>"+ (discQty*50 )+"</td></tr>");
		
		
		}
	newwindow.document.write("</table>");
}



