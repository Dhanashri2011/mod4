


function nWindow() {
		// TODO: get the height, width, left and top from the form object
		// and pass the values
		// to open method of window along with the name
		// of the html file to be opened in the new window.
		
		width= document.getElementById("Width").value;
		height= document.getElementById("Height").value;
		left= document.getElementById("Left").value;
		top= document.getElementById("Top").value;
		
		window.open("Lab5-1(newWindow).html","MessegeWindow", 
				"width="+width ,"height="+height,"left="+left , "top="+top );
}

