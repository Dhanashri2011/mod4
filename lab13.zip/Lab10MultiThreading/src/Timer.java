import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class Timer implements Runnable {
	private int time;
	int t, i;
	LocalTime sec = null;

	public Timer(int time) {
		this.time = time;
	}

	@Override
	public void run() {
		t = 1;
		i = 1;
		while (true) {

			if (i > 10) {
				i = 2;
				t++;
				if (t > time)
					break;
				sec = LocalTime.parse("00:00").plus(1, ChronoUnit.SECONDS);
				System.out.println(t + " turn " + sec);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			} else if (i == 1) {
				i++;
				sec = LocalTime.parse("00:00").plus(1, ChronoUnit.SECONDS);
				System.out.println(t + " turn " + sec);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} else {
				i++;
				sec = sec.plus(1, ChronoUnit.SECONDS);
				System.out.println(t + " turn " + sec);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}
}
