
public class TimerTest {
public static void main(String[] args) {
	Timer tm= new Timer(3);
	Thread t=new Thread(tm);
	t.start();
}
}
