
public class FileProgram {
public static void main(String[] args) {
	
	String src="C:\\Users\\mayuress\\Desktop\\source.txt";
	String target="C:\\Users\\mayuress\\Desktop\\target.txt";
	CopyDataThread cdt=new CopyDataThread(src,target);
	cdt.start();
	
}
}
