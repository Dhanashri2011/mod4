import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread {
	private String source;
	private String target;

	public CopyDataThread(String src, String target) {
		this.source = src;
		this.target = target;
	}

	@Override
	public void run() {
		FileInputStream inFile = null;
		FileOutputStream outFile = null;
		try {
			inFile = new FileInputStream(source);
			outFile = new FileOutputStream(target);
			int ch = 0;
			int i = 1;
			long ms1 = System.currentTimeMillis();
			while (true) {
				ch = inFile.read();
				if (ch == -1)
					break;
				outFile.write(ch);
				if (i % 10 == 0) {
					System.out.println("10 characters are copied");
					Thread.sleep(5000);
				}
				i++;
			}
			long ms2 = System.currentTimeMillis();
			System.out.println("File Copied Successfully in " + (ms2 - ms1)
					+ " ms");
		} catch (IOException | InterruptedException e) {
			System.out.println(e);
		} finally {
			try {
				inFile.close();
				outFile.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());

			}
		}
	}
}
