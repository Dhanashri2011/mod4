package lab13;

@FunctionalInterface
public interface LoginInterface {

	String showData();
}
