package lab13;

public interface EnterSpaceIn {

	 String enterSpace(String s);
}
