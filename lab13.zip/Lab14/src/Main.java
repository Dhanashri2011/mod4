import java.util.Scanner;


public class Main {

/*i)	Get employee details from user.
ii)	Find the insurance scheme for an employee based on salary and designation.
iii)	Display all the details of an employee*/

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		Employee emp=new Employee();
		Service service= new Service();
		String id;
		String sal;
		String des;
		String scheme;
		
		while (true){
			System.out.println("Enter your employee ID: ");
			 id=scan.next();
			if(service.validateID(id))
				break;	
			else
				System.out.println("Please enter a valid ID!");
		}
		while (true){
			System.out.println("Enter salary: ");
			 sal=scan.next();
			if(service.validateSalary(sal))
				break;	
			else
				System.out.println("Please enter a valid Salary amount!");
		}
		while (true){
			System.out.println("Enter your designation: ");
			 des=scan.next();
			if(service.validateDesignation(des))
				break;	
			else
				System.out.println("Please enter a valid designation!");
		}
		while (true){
			System.out.println("Enter your medical insurance scheme: ");
			scheme=scan.next();
			if(service.validateInsuranceScheme(scheme))
				break;	
			else
				System.out.println("Please enter a valid mediacl insurance scheme!");
		}
		
		
		
	}//main() closing
}//clss closing
