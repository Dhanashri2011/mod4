
public class Service implements ServiceInterface {

	@Override
	public boolean validateID(String ID) {
		return ID.matches(IDPattern);
	}

	@Override
	public boolean validateName(String name) {
		return name.matches(namePattern);
	}

	@Override
	public boolean validateSalary(String salary) {
		return salary.matches(SalaryPattern);
	}

	@Override
	public boolean validateDesignation(String designation) {
		return designation.matches(DesignationPattern);
	}

	@Override
	public boolean validateInsuranceScheme(String insuranceScheme) {
		return insuranceScheme.matches(InsuranceSchemePattern);
	}

	

}
