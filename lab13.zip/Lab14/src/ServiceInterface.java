
public interface ServiceInterface {

	String IDPattern="[0-9]{10}";
	String namePattern="[a-z A-Z]{50}";
	String SalaryPattern="[0-9]{10}";
	String DesignationPattern="[a-zA-Z]{20}";	
	String InsuranceSchemePattern="[a-zA-Z]{20}";
	
	
	public boolean validateID(String ID);
	public boolean validateName(String name);
	public boolean validateSalary(String salary);
	public boolean validateDesignation(String designation);
	public boolean validateInsuranceScheme(String insuranceScheme);
	
}
