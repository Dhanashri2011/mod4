import java.util.Scanner;

public class SortAlphabets {
	public String[] getSortedalphabets(String... arr) {
		String temp = "";
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++)
				if (arr[i].compareTo(arr[j]) > 0) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
		}

		return arr;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of letters you want to sort");
		int n = sc.nextInt();
		String[] arr = new String[n];

		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.next().toLowerCase();
		}
		SortAlphabets sa = new SortAlphabets();
		String sort[] = sa.getSortedalphabets(arr);
		for (int i = 0; i < sort.length; i++)
			if(i<Math.ceil(sort.length/2.0))
			System.out.print(sort[i].toUpperCase());
			else System.out.print(sort[i].toLowerCase());
	}
}
