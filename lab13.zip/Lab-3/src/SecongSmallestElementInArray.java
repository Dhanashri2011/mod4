import java.util.Arrays;
import java.util.Scanner;


public class SecongSmallestElementInArray {
double getSecondSmallest (double[] numbers){
	Arrays.sort(numbers);
	return numbers[1];
}

public static void main(String[] args) {
	 Scanner scan=new Scanner(System.in);
     System.out.println("enter number of elements");
     int n=scan.nextInt();
     int arr[]=new int[n];

     System.out.println("enter elements");

     for(int i=0;i<n;i++){//for reading array
         arr[i]=scan.nextInt();

     }

     for(int i: arr){ //for printing array

         System.out.println(i);

     }
 }
}

