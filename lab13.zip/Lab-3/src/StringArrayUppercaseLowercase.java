import java.util.Scanner;

//Create a method that can accept an array of String objects 
//and sort in alphabetical order. The elements in the left half should be completely in 
//uppercase and the elements in the right half should be completely in lower case. Return the resulting array.
//Note: If there are odd number of String objects, then (n/2) +1 elements should be in UPPPERCASE

public class StringArrayUppercaseLowercase {

	static void UppercaseLowercase(String[] array , int index){
			
			for(int index1=0;index1<=index/2;index1++)
	        System.out.println(array[index1].toLowerCase());
			for(int index2=0;index>=index2 && index2>index/2;index2++)
		        System.out.println(array[index2].toLowerCase());
		}
	public static void main(String[] args) {
		 String[] inputarray;
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the number of names: " );
		int arrayIndex=scan.nextInt();
		System.out.println("Enter the of names: " );
		for(int temp=0;temp<arrayIndex;temp++){
			inputarray[temp]= scan.next();
		}
		
		UppercaseLowercase(inputarray[] , arrayIndex);
	}
}

