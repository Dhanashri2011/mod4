//Create a class with a method to find the difference between the sum of the 
//squares and the square of the sum of the first n natural numbers.

import java.util.Scanner;


public class SquareSum 
{
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n= scan.nextInt();
		System.out.println("Difference between sum of square and square of sum is : "+ square(n));
	}
	 static int square(int n)
	 {
		 
		 int sum=0;
		 int sum1=0;
			
		for(int temp=1;temp<=n;temp++)
		{
			int a= temp*temp;
			sum=sum+a;
		}
		for(int temp1=1;temp1<=n;temp1++)
		{
			sum1=sum1+temp1;
		}
		int b=sum1*sum1;
		int a= sum-b;
		return a;
	}
	
	
	
}
