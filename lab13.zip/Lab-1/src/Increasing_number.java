//Create a method to check if a number is an increasing number

import java.util.Scanner;


public  class Increasing_number {
	 static int num;
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number: ");
		num=scan.nextInt();
		Increasing_number(num);
		 if(Increasing_number(num)){
			    System.out.println("Number is not increasing");}
			    else{
			    	 System.out.println("Number is increasing");
			    }
		}
	
	static boolean Increasing_number(int number){
		boolean flag=false;
	    int currentNum=number%10;
	   number=number/10;
	    while (number>0)
	    {
	    	if(number%10>=currentNum)
	    	{
	    		flag=true;
	    		break;
	    	}
	    		currentNum=number%10;
	    		  number=number/10;
	    }
	   return flag;
	}
}
