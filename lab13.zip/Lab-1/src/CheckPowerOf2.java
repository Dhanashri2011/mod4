//Create a method to check if a number is a power of two or not
import java.util.Scanner;


public class CheckPowerOf2 {
	
	static boolean checkNumber(double num){
		boolean flag;
		 if (num == 0) 
	            flag= false; 
	          
	        while (num != 1) 
	        { 
	            if (num % 2 != 0) 
	                return false; 
	            num = num / 2; 
	        } 
	        flag= true; 
		return flag;
	}
	
	
public static void main(String[] args) {
	double number;
	Scanner scan= new Scanner(System.in);
	System.out.println("Enter the number: " );
	number= scan.nextInt();
	if(checkNumber(number)==true)
		System.out.println("Number is power of 2 " );
	else
		System.out.println("Number is not power of 2 " );
}
}
