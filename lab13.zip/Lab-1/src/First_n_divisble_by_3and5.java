//Create a class with a method which can calculate the sum of first n natural numbers which are divisible by 3 or 5.

import java.util.Scanner;

public class First_n_divisble_by_3and5 
{
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the num: ");
		int n= scan.nextInt();
		CalculateSum(n);
		System.out.println("Sum of first "+ n +"natural numbers divisible by 3 or 5 is "+ CalculateSum(n));
		}
	
	public static int CalculateSum(int n)
	{
		int sum=0;
		
		
		int num=1 ; 
		int count=0;
		while(num>0)
		{
			if(num%3==0 || num%5==0)
			{sum+=num;
			count++;
			}
			if(count==n)
			{break;}
			else
			{num++;}
		}
		return sum;
	}
	
}
