
public class Age {
	private int age ;

	public Age(int age) {
		this.age = age;
	}
	public void checkAge()throws AgeException{
		if(age<15){
			throw new AgeException("age is invalid");
		}
		else
		{
			displayAge();
		}
		}
		public void displayAge(){
			System.out.println("Age of perso is " + age);
	}
	

}
