import java.util.Scanner;


public class Fibonacci {
public static void main(String[] args) {
	int a=0,b=1;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter nth digit you want to print Fibonacci series");
	int num=sc.nextInt();
	int temp=0;
	if(num>=2)
	{
	System.out.print(a + " "+ b);
	for(int i=0;i<num-2;i++)
	{
		temp=a+b;
		a=b;
		b=temp;
		System.out.print(" "+temp);
	}
	}else System.out.println("Fibonacci series number should be greater than 2");
}
}
