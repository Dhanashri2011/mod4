public class TrafficLight {

	private String ColourOfLight;
	public char[] TrafficFlow;

	public TrafficLight(String colourOfLight) {

		this.ColourOfLight = colourOfLight;
	}

	public String TrafficFlow() {

		if (ColourOfLight == "Red") {
			return "stop";
		} else if (ColourOfLight == "yellow") {
			return "ready";
		} else if (ColourOfLight == "green") {
			return "go";
		}
		return "wrong color";

	}
}
