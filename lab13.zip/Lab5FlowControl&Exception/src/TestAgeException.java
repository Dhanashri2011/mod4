
public class TestAgeException {
public static void main(String[] args) {
	Age g = new Age(12);

		try {
			g.checkAge();
		} catch (AgeException e) {
			System.out.println(e.getMessage());
		}
	}
}

