
public class AgeException extends Exception {
	public AgeException(String arg0){
		super(arg0);
	}

}
