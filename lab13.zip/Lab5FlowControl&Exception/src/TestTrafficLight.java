
public class TestTrafficLight {
public static void main(String[] args) {
	TrafficLight test1 = new TrafficLight("red");
	TrafficLight test2 = new TrafficLight("yellow");
	TrafficLight test3 = new TrafficLight("green");
	  
	
	System.out.println(test1.TrafficFlow());
	System.out.println(test2.TrafficFlow());
	System.out.println(test3.TrafficFlow());
}
}
