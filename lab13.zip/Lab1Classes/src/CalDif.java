class Difference
{
	Difference(){}
	public double calculateDifference(double ... num) 
	{
		double square=0;
		double sum=0;
		double dif=0;
		for(double temp:num)
		{
			 square+= Math.pow(temp, 2);
		}
		for(double temp:num)
		{
			sum+=temp;
		}
		double sqSum=Math.pow(sum, 2);
		dif=square-sqSum;
		return Math.abs(dif);
	}
}
public class CalDif {
	public static void main(String[] args) {
		Difference num= new Difference();
		double result=num.calculateDifference(4,8,9,56,3,27,1,25.2,4);
		System.out.println(result);
		result=num.calculateDifference(4,3);
		System.out.println(result);
		
	}

}
