class ChkNumber{
	 
	ChkNumber(){}
	boolean checkNumber(long num)
	{
		double log = Math.log(num)/Math.log(2);
	    double pow = Math.pow(2, Math.round(log));
	    return pow == num;
	}
	int callMe(int no){
			no++;
		return no;
	}
}
public class CheckN {
	static int no;
	public static void main(String[] args) {
		ChkNumber num=new ChkNumber();
		boolean isPowerof2 = num.checkNumber(64);
		//System.out.println(isPowerof2);
		String s1 = "Hello";  
        String s2 = s1;  
  String s3 = new String("Hello");  
  String s4 = new String("Hello");  
  String s5 = "Hello";  
  System.out.println(s1 == s5);  
  System.out.println(s1 == s2);  
  System.out.println(s1.equals(s2));  
  System.out.println(s3 == s4);  
  System.out.println(s3 == s1);  
  System.out.println(s3.equals(s4));  
  for(int i = 0; i < 2; i++) {
      for(int j = 2; j>= 0; j--) {
        if(i == j) break;
        System.out.println("i=" + i + " j="+j);
      }
   }

	}
}
