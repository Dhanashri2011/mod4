import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class SquareMap {
	private static Map<Integer, Double> getSquare(int...arr) {
		HashMap<Integer, Double> map = new HashMap<Integer, Double>();
		ArrayList<Integer> list = new ArrayList<Integer>(arr.length);
		for (int i : arr) {
			list.add(i);
		}
		double square = 0;
		// for (int i : arr) {
		// square=Math.pow(i, 2);
		// map.put(i, square);
		// }
		Iterator<Integer> it = list.iterator();
		int temp = 0;
		while (it.hasNext()) {
			temp = it.next();
			square = Math.pow(temp, 2);
			map.put(temp, square);
		}
		return map;

	}

	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter How many integer You want to enter");
//		int len = sc.nextInt();
//		int[] arr = new int[len];
//		for (int i = 0; i < len; i++)
//			arr[i] = sc.nextInt();

		System.out.println(getSquare(2,5,9,6));

	}
}
