/* Lab 8
 * A program that displays the number of characters, lines and words in a text.
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class DisplayCount {
	
	public void calculateCount() {
		int charCount=0,lineCount=0,wordCount=0;
		String line;
		FileInputStream fis;
		try {
			fis = new FileInputStream("CountLine.txt");
			Scanner sc = new Scanner(fis);
			while(sc.hasNextLine()) {
				line = sc.nextLine();
				String[] words = line.split("\\s+");
				wordCount+= words.length;
				lineCount++;
				charCount+= line.toCharArray().length;
			}
			System.out.println("No of characters: "  + charCount + "\nNo of words: " + 
			wordCount + "\nNo of lines: " + lineCount);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args){
		DisplayCount dc = new DisplayCount();
		dc.calculateCount();
	}
}
