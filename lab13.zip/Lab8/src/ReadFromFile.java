/*
 * Lab 8
 * Program that reads a file and displays the file on the screen,
 * with a line number before each line.
 */


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class ReadFromFile {
	public static void main(String[] args) {
		String s;
		int count = 0;
		try {
			FileReader fr = new FileReader("CountLine.txt");
			BufferedReader br = new BufferedReader(fr);
			while((s = br.readLine()) != null)
			{
				count++;
				System.out.println(count + " " +s);
			}
		} catch (IOException e) { 
			System.out.println("io error"); 
		}
	}
}
