import java.io.File;
import java.util.Scanner;


public class DisplayFileDetails {
	public void getExtensionType(File f) {
		String name = f.getName();
		int indx = name.lastIndexOf(".");
		System.out.println((indx == -1) ? " " : name.substring(indx+1));  
	}
	public static void main(String[] args) {
	
		File f = new File("C:/Users/prawati/Downloads/begin.pdf");
		
		// to check if file exists
		if (f.exists()) {
			System.out.println("File exists");
		} else {
			System.out.println("File does not exists");
		}
		// to check if file is readable
		if (f.canRead()) {
			System.out.println("File is readable");
		} else {
			System.out.println("File is not readable");
		}
		// to check if file is writable
		if (f.canWrite()) {
			System.out.println("File is writable");
		} else {
			System.out.println("File is not writable");
		}
		// display length of file
		System.out.println("Length of file is: " + f.length() + " bytes");
		DisplayFileDetails df = new DisplayFileDetails();
		df.getExtensionType(f);
	}
}
